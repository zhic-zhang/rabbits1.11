<html>
<head>
<title>Linux优化大师</title>
</head>
<div class="text" style=" text-align:center;">
<h1><b>Linux优化大师</b></h1>
<h5>开源地址:https://github.com/Ops2018/rabbits1.0</h5>
</div>
<body>
<center>
<button type="button" onclick="{location.href='http://123.206.81.19:9092/memory_monitor'}">内存监控</button>
<button type="button" onclick="{location.href='http://123.206.81.19:9092/cpu_monitor'}">cpu监控</button>
</center>
<div>
<h3><b>功能说明：</b></h3></br>
1、性能监控（目前只支持内存、cpu的监控）</br>
2、一键调优（如果没有定义则采用默认的调优方案）</br>
3、设计自定义的优化行为</br>

<h3><b>我不会调优怎么办？</b></h3></br>
您可以采用本系统默认的调优方案，或者您可以发送邮件到以下邮箱来联系创作团队，以获得企业级定制优化方案</br>
联系邮箱：1398272655@qq.com</br>

<h3><b>出现了bug怎么办？</b></h3></br>
1、本系统是基于flask+php+html5，目前已开源，您可以访问https://github.com/Ops2018/rabbits1.0，
下载源码后您可以自行修改</br>
2、若您仍无法解决故障，您可以发送邮件到以下邮箱来联系创作团队，以获得<b>企业级维护方案</b></br>
联系邮箱：1398272655@qq.com</br>

<h3><b>怎么加入你们？</b></h3></br>
我们隶属于OPS，致力于开源创新。您可以发送一封关于描述您的邮件到ops_engineer@foxmail.com，审核
通过后我们会马上回复邮件。我们欢迎您的加入，我们是心向无界的圣骑士，OPS是我们的家园，让我们携
手共进吧！！！
</div>

</body>
</html>

