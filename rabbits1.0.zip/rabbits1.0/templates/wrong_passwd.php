<html>
<head>
<title>运维性能监控平台</title>
</head>
<div class="text" style=" text-align:center;"><b>运维性能监控平台</b></div>
<br/>
<body>
<center>
用户名或密码有误
<br/>
<br/>
<button type="button" onclick="{location.href='http://123.206.81.19:9092/login'}">返回登陆界面</button>
</center>
</body>
</html>
